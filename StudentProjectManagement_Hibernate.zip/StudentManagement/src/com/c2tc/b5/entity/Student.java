package com.c2tc.b5.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;



@Entity
@Table(name="Student")
@NamedQueries(@NamedQuery(name = "getAllData", query = "SELECT s FROM Student s"))
public class Student {
	private int id;
	private String name;
	private String collegename;
	private int roll;
	private String qualification;
	private String course;
	private int year;
	private String certificatename;
	private int hallTicketNo;
	
	
	public Student() {
		super();
	}

	@Id
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCollegename() {
		return collegename;
	}
	public void setCollegename(String collegename) {
		this.collegename = collegename;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getCertificatename() {
		return certificatename;
	}
	public void setCertificatename(String certificatename) {
		this.certificatename = certificatename;
	}
	public int getHallTicketNo() {
		return hallTicketNo;
	}
	public void setHallTicketNo(int hallTicketNo) {
		this.hallTicketNo = hallTicketNo;
	}
	
	public Student(int id, String name, String collegename, int roll, String qualification, String course, int year,
			String certificatename, int hallTicketNo) {
		super();
		this.id = id;
		this.name = name;
		this.collegename = collegename;
		this.roll = roll;
		this.qualification = qualification;
		this.course = course;
		this.year = year;
		this.certificatename = certificatename;
		this.hallTicketNo = hallTicketNo;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", collegename=" + collegename + ", roll=" + roll
				+ ", qualification=" + qualification + ", course=" + course + ", year=" + year + ", certificatename="
				+ certificatename + ", hallTicketNo=" + hallTicketNo + "]";
	}

}
