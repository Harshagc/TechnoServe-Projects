package com.c2tc.b5.Service;

import java.util.List;

import com.c2tc.b5.StudRepo.StudentRepo;
import com.c2tc.b5.StudRepo.StudentRepoImpl;
import com.c2tc.b5.entity.Student;

public class StudentServiceImpl implements StudentService{

	
	StudentRepo cri;
	
	public StudentServiceImpl() {
		cri= new StudentRepoImpl();
	}

	//adding student operation takes place
	@Override
	public void addStudent(Student student) {
		cri.startTransaction();
		cri.addStudent(student);
		cri.endTransaction();
		
	}
	
	//Retrieving student operation takes place
	@Override
	public List<Student> searchStudent(int id) {
		return cri.searchStudent(id);
	}
	
	@Override
	public List<Student> getAllData() {
		return cri.getAllData();
	}
	
	@Override
	public Student deleteStudent(int id3) {
		return cri.deleteStudent(id3);
	}

	@Override
	public Student updateStudent(int id) {
		return cri.updateStudent(id);
	}

}
