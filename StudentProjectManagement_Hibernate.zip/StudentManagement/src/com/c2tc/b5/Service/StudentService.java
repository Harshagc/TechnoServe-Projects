package com.c2tc.b5.Service;

import java.util.List;

import com.c2tc.b5.entity.Student;

public interface StudentService {

	public void addStudent(Student student);
	
	public List<Student> searchStudent(int id);
	public List<Student> getAllData();

	
	public Student deleteStudent(int id3);
	
	public Student updateStudent(int id);
	

}
