package com.c2tc.b5.StudRepo;

import java.util.List;

import com.c2tc.b5.entity.Student;


public interface StudentRepo {
	public void addStudent(Student student);
	
	public List<Student> searchStudent(int id);
	public List<Student> getAllData();

	
	public Student deleteStudent(int id3);
	
	public Student updateStudent(int id);
	 
	public void startTransaction();
	public void endTransaction();


}
