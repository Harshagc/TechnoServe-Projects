package com.c2tc.b5.StudRepo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.c2tc.b5.entity.Student;

public class StudentRepoImpl implements StudentRepo {

	EntityManager em;

	public StudentRepoImpl() {
		em=Configuration.createEntityManager();

	}
	
	@Override
	public void addStudent(Student student) {
		em.persist(student);
	}

	@Override
	public List<Student> searchStudent(int id) {
		String query="Select s from Student s WHERE s.id like : id";
		TypedQuery<Student> t=em.createQuery(query, Student.class);
		t.setParameter("id", id);
		return t.getResultList();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> getAllData() {
		Query query= em.createNamedQuery("getAllData");
		List<Student> list= query.getResultList();
		return list;	
		
	}

	@Override
	public Student deleteStudent(int id3) {
		em.getTransaction().begin();
		Student student2 = em.find(Student.class, id3);
		em.remove(student2);
		em.getTransaction().commit();
		return student2;
	
	}

	@Override
	public Student updateStudent(int id) {
		em.getTransaction().begin();
		Student student1 = em.find(Student.class, id);
		student1.setCollegename("SRM");
		em.getTransaction().commit();
		return student1;
		
	}

	@Override
	public void startTransaction() {
		em.getTransaction().begin();
		
	}

	@Override
	public void endTransaction() {
		em.getTransaction().commit();
		
	}
	

}
