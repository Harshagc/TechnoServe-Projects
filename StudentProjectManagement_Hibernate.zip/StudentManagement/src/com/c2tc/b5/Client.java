package com.c2tc.b5;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.c2tc.b5.Service.StudentService;
import com.c2tc.b5.Service.StudentServiceImpl;
import com.c2tc.b5.entity.Student;

public class Client {

	public static void main(String[] args) {
		
		//Doing object creation for CRUD operations
				StudentService cs=new StudentServiceImpl();
				Scanner sc = new Scanner(System.in);



	//Student(int id, String name, String collegename, int roll, String qualification, String course, int year,
	//String certificatename, int hallTicketNo)
				
				//Creating or adding college data to Student database
				Student student=new Student(35,"Amulya","UVCE",1791,"BE","Information Science",2021,"Participation",46925761);
				cs.addStudent(student);
				
				//Retrieving the data
				int id1;
				try {
				System.out.print("Please enter student identity code to print that student details: ");
				id1=sc.nextInt();
				System.out.println();
				List<Student> li= cs.searchStudent(id1);
				for(Student c : li)
					System.out.println(c);
				}
				catch(Exception e) {
					System.out.println(e+ "\n Please enter correct data to Add..!");
				}

				//Retrieve all data Operation
				System.out.println("\n" + "Printing All Data From Student " + "\n");
				List<Student> li4=cs.getAllData();
				Iterator<Student> it=li4.iterator();
				while(it.hasNext())
					System.out.println(it.next());

				//Update Student data operation
				int id2;
				try {
				System.out.print("\n" + "Please enter Student identity code to update that Student-Collegename: ");
				id2=sc.nextInt();
				System.out.println();
				Student c1=cs.updateStudent(id2);
				System.out.println(c1);
				}
				catch (Exception e) {
					System.out.println(e+ "\n Please enter correct Update data..!");
				}
				
				//Delete id Operation
				try {
				System.out.print("\n" + "Please enter student identity code to Delete that data: ");
				int id3=sc.nextInt();
				System.out.println();
				System.out.print(cs.deleteStudent(id3) + "\n" + "\n"+ "deleted successfully");
				}
				catch(Exception e) {
					System.out.println(e+ "Invalid input: Please enter valid data to delete that entire row..!");
				}
				sc.close();
					
			}

}


