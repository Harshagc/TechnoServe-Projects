package technoserve.c2tc.b5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
