package technoserve.c2tc.b5.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import technoserve.c2tc.b5.entity.College;

public interface CollegeRepository extends JpaRepository<College,Integer>{

}
